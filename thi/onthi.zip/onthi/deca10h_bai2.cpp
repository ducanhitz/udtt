#include <iostream>
#include <iomanip>

using namespace std;

string hoTen[10] = {"Nguyen Duc Anh", "Chu Van Manh", "Dang Duc Tho", "Cao Ba Loc", "Nguyen Lan Duy",
                    "Le Minh Hieu", "Ngo Tho Ngoc", "Pham Tuan Nghia", "Nguyen Van Phuc", "Nguyen Dinh Anh"};
int luong[10] = {
    90000000,
    50000000,
    18000000,
    15000000,
    5000000,
    4500000,
    4000000,
    3000000,
    2000000,
    1500000,
};

struct CongNhan
{
    string hoTen;
    int luong;
};

void Nhap(CongNhan cn[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cn[i].hoTen = hoTen[i];
        cn[i].luong = luong[i];
    }
}

int TimKiemNhiPhan(CongNhan cn[], int left, int right, int x)
{
    if (left >= right)
        return left;
    int middle = (left + right) / 2;
    if (x > cn[middle].luong)
        return TimKiemNhiPhan(cn, left, middle - 1, x);
    return TimKiemNhiPhan(cn, middle + 1, right, x);
}

void ChenX(CongNhan cn[], int &n, CongNhan X, int k)
{
    for (int i = n; i >= k; i--)
        cn[i] = cn[i - 1];
    cn[k] = X;
    n++;
}

void LayLuong(CongNhan cn[], int m)
{
    int i = 0;
    while (m > 0 && m >= cn[i].luong)
    {
        m -= cn[i].luong;
        cout << setw(18) << left << cn[i].hoTen << " " << cn[i].luong << endl;
        i++;
    }
}

void Sort(CongNhan cn[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (cn[i].luong < cn[j].luong)
            {
                CongNhan temp = cn[i];
                cn[i] = cn[j];
                cn[j] = temp;
            }
        }
    }
}

int main()
{
    CongNhan cn[11];
    int n = 10;

    Nhap(cn, n);

    CongNhan cn_new = {"Nguyen Van Test", 5500000};
    int vitri = TimKiemNhiPhan(cn, 0, n - 1, cn_new.luong) + 1;
    cout << "Vi tri de chen cong nhan moi vao danh sach la: " << vitri << endl;
    ChenX(cn, n, cn_new, vitri);
    for (int i = 0; i < n; i++)
    {
        cout << setw(18) << left << cn[i].hoTen << " " << cn[i].luong << endl;
    }

    Sort(cn, n);
    int p = 160000000;
    cout << "Can lay luong cua cac cong nhan sau de luong khong vuot qua " << p << ": " << endl;
    LayLuong(cn, p);

    return 0;
}